/* rtc not implemented yet */

extern int cma_rtc_not_implemented;
